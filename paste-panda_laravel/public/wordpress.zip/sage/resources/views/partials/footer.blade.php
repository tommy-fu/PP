<footer class="pt-32 pb-32" style="background: #EAEAEA;">
    <div class="container">
        <div class="m-b-8" style="display: flex; justify-content: center;">
            <div class="footer-link" style="padding: 0 12px;">Om oss</div>
            <div class="footer-link" style="padding: 0 12px;">Hem</div>
            <div class="footer-link" style="padding: 0 12px;">Blogg</div>
            <div class="footer-link" style="padding: 0 12px;">Cookies</div>
            <div class="footer-link" style="padding: 0 12px;">Terms</div>
        </div>

        <div class="m-b-6" style="display: flex; justify-content: center;">
            <div style="padding: 0 10px;">
                LinkedIn
            </div>

            <div style="padding: 0 10px;">
                Facebook
            </div>

            <div style="padding: 0 10px;">
                Instagram
            </div>
        </div>

        <div class="footer-copyright has-text-centered">
            © 2020 Stillin. All rights reserved.
        </div>
    </div>
</footer>
