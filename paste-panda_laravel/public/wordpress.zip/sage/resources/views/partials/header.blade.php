<div class="section pt-24 pb-24" style="background: #fff;">
	<div class="container">

		<div style="display: flex; justify-content: space-between;">
			<div class="nav-brand">
				Stillin
			</div>

			<div class="is-hidden is-flex-tablet" style="justify-content: space-between;">

				<div class="__nav-item" style="padding: 0 20px;">
					<a class="nav-link">
						Blogg
					</a>
				</div>
				<div class="__nav-item" style="padding: 0 20px;">
					<a class="nav-link">
						Om oss
					</a>
				</div>

				<div class="__nav-item" style="padding: 0 20px;">
					<a class="nav-link">
						Kom igång
					</a>

				</div>





			</div>
		</div>
	</div>
</div>
